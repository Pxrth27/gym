package com.example.gym;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

   EditText username,Password;
   Button button0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username=findViewById(R.id.usrename);
        Password=findViewById(R.id.Password);
        button0=findViewById(R.id.button0);

        button0.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                checkcrededentials();
            }
        });
    }
    private void checkcrededentials() {

        String usrename=username.getText().toString();
        String password=Password.getText().toString();

        if (usrename.isEmpty() || !usrename.contains("@"))
        {
            showError(username,"your email is not vaid");
        }
        else if (password.isEmpty() || password.length()<7)
        {
            showError(Password,"password must be 7 character");
        }
        else
        {
            Toast.makeText(this, "login", Toast.LENGTH_SHORT).show();
        }
    }
    private void showError(EditText input, String s) {
        input.setError(s);
        input.requestFocus();
    }
}