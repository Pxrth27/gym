package com.example.gym;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText Inputusername,Inputemail,Password,Repassword;
    Button btnsubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Inputusername=findViewById(R.id.inputusername);
        Inputemail=findViewById(R.id.inputemail);
        Password=findViewById(R.id.Password);
        Repassword=findViewById(R.id.Repassword);
        btnsubmit=findViewById(R.id.btnsubmit);
        btnsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkcrededentials();
            }
        });

    }
    private void checkcrededentials() {
        String username=Inputusername.getText().toString();
        String email=Inputemail.getText().toString();
        String password=Password.getText().toString();
        String repassword=Repassword.getText().toString();

        if (username.isEmpty() || username.length()<5)
        {
            showError(Inputusername,"your user name is not valid");
        }
        else if (email.isEmpty() || !email.contains("@"))
        {
            showError(Inputemail,"your email is not vaid");
        }
        else if (password.isEmpty() || password.length()<7)
        {
            showError(Password,"password must be 7 character");
        }
        else if (repassword.isEmpty() || !repassword.equals(password))
        {
            showError(Repassword,"passeord is not match!");
        }
        else
        {
            Toast.makeText(this, "call Registration", Toast.LENGTH_SHORT).show();
        }
    }


    private void showError(EditText input, String s) {
        input.setError(s);
        input.requestFocus();
    }

    public void openActivity(View v){
        Toast.makeText(this, "Login", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this,LoginActivity.class);
        startActivity(intent);
    }
}
